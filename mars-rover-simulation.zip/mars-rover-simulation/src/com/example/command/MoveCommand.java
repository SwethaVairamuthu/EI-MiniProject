package com.example.command;

import com.example.model.Rover;

public class MoveCommand implements Command {
    @Override
    public void execute(Rover rover) {
        rover.moveForward();
    }
}
