package com.example.command;

import com.example.model.Rover;

public interface Command {
    void execute(Rover rover);
}
