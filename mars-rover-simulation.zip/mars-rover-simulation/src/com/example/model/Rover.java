package com.example.model;

import com.example.command.Command;

public class Rover {
    private int x;
    private int y;
    private Direction direction;
    private Grid grid;

    public Rover(int x, int y, Direction direction, Grid grid) {
        this.x = x;
        this.y = y;
        this.direction = direction;
        this.grid = grid;
    }

    public void moveForward() {
        int newX = x;
        int newY = y;

        switch (direction) {
            case NORTH: newY++; break;
            case EAST: newX++; break;
            case SOUTH: newY--; break;
            case WEST: newX--; break;
        }

        if (grid.isWithinBounds(newX, newY) && !grid.isObstacle(newX, newY)) {
            x = newX;
            y = newY;
        }
    }

    public void turnLeft() {
        direction = Direction.values()[(direction.ordinal() + 3) % 4];
    }

    public void turnRight() {
        direction = Direction.values()[(direction.ordinal() + 1) % 4];
    }

    public String getStatus() {
        return String.format("Rover is at (%d, %d) facing %s.", x, y, direction);
    }
}
