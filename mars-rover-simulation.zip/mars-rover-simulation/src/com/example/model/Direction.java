package com.example.model;

public enum Direction {
    NORTH, EAST, SOUTH, WEST
}
