package com.example;

import com.example.command.Command;
import com.example.command.MoveCommand;
import com.example.command.TurnLeftCommand;
import com.example.command.TurnRightCommand;
import com.example.model.Direction;
import com.example.model.Grid;
import com.example.model.Obstacle;
import com.example.model.Rover;

public class Main {
    public static void main(String[] args) {
        Grid grid = new Grid(10, 10);
        grid.addObstacle(new Obstacle(2, 2));
        grid.addObstacle(new Obstacle(3, 5));

        Rover rover = new Rover(0, 0, Direction.NORTH, grid);
        Command move = new MoveCommand();
        Command turnLeft = new TurnLeftCommand();
        Command turnRight = new TurnRightCommand();

        // Sample commands
        move.execute(rover);
        move.execute(rover);
        turnRight.execute(rover);
        move.execute(rover);
        turnLeft.execute(rover);
        move.execute(rover);

        System.out.println(rover.getStatus());
    }
}
