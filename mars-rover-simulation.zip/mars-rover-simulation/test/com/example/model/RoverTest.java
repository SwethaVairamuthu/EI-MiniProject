package com.example.model;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class RoverTest {
    private Rover rover;
    private Grid grid;

    @Before
    public void setUp() {
        grid = new Grid(10, 10);
        rover = new Rover(0, 0, Direction.NORTH, grid);
    }

    @Test
    public void testMoveForward() {
        rover.moveForward();
        assertEquals("Rover is at (0, 1) facing NORTH.", rover.getStatus());
    }

    @Test
    public void testTurnLeft() {
        rover.turnLeft();
        assertEquals("Rover is at (0, 0) facing WEST.", rover.getStatus());
    }

    @Test
    public void testTurnRight() {
        rover.turnRight();
        assertEquals("Rover is at (0, 0) facing EAST.", rover.getStatus());
    }
}
