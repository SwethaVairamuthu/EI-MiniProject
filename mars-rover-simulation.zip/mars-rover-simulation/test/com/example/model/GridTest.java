package com.example.model;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;

public class GridTest {
    private Grid grid;

    @Before
    public void setUp() {
        grid = new Grid(10, 10);
        grid.addObstacle(new Obstacle(2, 2));
    }

    @Test
    public void testIsObstacle() {
        assertTrue(grid.isObstacle(2, 2));
        assertFalse(grid.isObstacle(3, 3));
    }

    @Test
    public void testIsWithinBounds() {
        assertTrue(grid.isWithinBounds(0, 0));
        assertFalse(grid.isWithinBounds(-1, 0));
        assertFalse(grid.isWithinBounds(0, 10));
    }
}
