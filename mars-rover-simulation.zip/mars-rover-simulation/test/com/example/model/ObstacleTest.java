package com.example.model;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class ObstacleTest {
    @Test
    public void testObstacleCreation() {
        Obstacle obstacle = new Obstacle(2, 3);
        assertEquals(2, obstacle.getX());
        assertEquals(3, obstacle.getY());
    }
}
