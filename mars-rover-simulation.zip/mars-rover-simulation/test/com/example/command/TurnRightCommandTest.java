package com.example.command;

import com.example.model.Direction;
import com.example.model.Grid;
import com.example.model.Obstacle;
import com.example.model.Rover;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class TurnRightCommandTest {
    private Rover rover;
    private Grid grid;
    private Command turnRightCommand;

    @Before
    public void setUp() {
        grid = new Grid(10, 10);
        rover = new Rover(0, 0, Direction.NORTH, grid);
        turnRightCommand = new TurnRightCommand();
    }

    @Test
    public void testTurnRight() {
        turnRightCommand.execute(rover);
        assertEquals("Rover is at (0, 0) facing EAST.", rover.getStatus());
    }
}
