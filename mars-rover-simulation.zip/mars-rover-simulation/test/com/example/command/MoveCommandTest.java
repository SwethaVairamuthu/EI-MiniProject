package com.example.command;

import com.example.model.Direction;
import com.example.model.Grid;
import com.example.model.Obstacle;
import com.example.model.Rover;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class MoveCommandTest {
    private Rover rover;
    private Grid grid;
    private Command moveCommand;

    @Before
    public void setUp() {
        grid = new Grid(10, 10);
        grid.addObstacle(new Obstacle(2, 2));
        rover = new Rover(0, 0, Direction.NORTH, grid);
        moveCommand = new MoveCommand();
    }

    @Test
    public void testMoveForward() {
        moveCommand.execute(rover);
        assertEquals("Rover is at (0, 1) facing NORTH.", rover.getStatus());
    }
}
