package com.example.command;

import com.example.model.Direction;
import com.example.model.Grid;
import com.example.model.Obstacle;
import com.example.model.Rover;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class TurnLeftCommandTest {
    private Rover rover;
    private Grid grid;
    private Command turnLeftCommand;

    @Before
    public void setUp() {
        grid = new Grid(10, 10);
        rover = new Rover(0, 0, Direction.NORTH, grid);
        turnLeftCommand = new TurnLeftCommand();
    }

    @Test
    public void testTurnLeft() {
        turnLeftCommand.execute(rover);
        assertEquals("Rover is at (0, 0) facing WEST.", rover.getStatus());
    }
}
